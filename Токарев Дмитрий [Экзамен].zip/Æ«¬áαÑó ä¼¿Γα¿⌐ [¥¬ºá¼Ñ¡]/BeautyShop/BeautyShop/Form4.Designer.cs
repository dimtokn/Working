﻿namespace BeautyShop
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.beautyShopDataSet = new BeautyShop.BeautyShopDataSet();
            this.услуги1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.услуги1TableAdapter = new BeautyShop.BeautyShopDataSetTableAdapters.Услуги1TableAdapter();
            this.кодуслугиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеУслугиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценарубDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типуслугиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодсотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beautyShopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.услуги1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(394, 73);
            this.label1.TabIndex = 16;
            this.label1.Text = "BeautyShop";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодуслугиDataGridViewTextBoxColumn,
            this.наименованиеУслугиDataGridViewTextBoxColumn,
            this.ценарубDataGridViewTextBoxColumn,
            this.типуслугиDataGridViewTextBoxColumn,
            this.кодсотрудникаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.услуги1BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(2, 155);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(781, 267);
            this.dataGridView1.TabIndex = 17;
            // 
            // beautyShopDataSet
            // 
            this.beautyShopDataSet.DataSetName = "BeautyShopDataSet";
            this.beautyShopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // услуги1BindingSource
            // 
            this.услуги1BindingSource.DataMember = "Услуги1";
            this.услуги1BindingSource.DataSource = this.beautyShopDataSet;
            // 
            // услуги1TableAdapter
            // 
            this.услуги1TableAdapter.ClearBeforeFill = true;
            // 
            // кодуслугиDataGridViewTextBoxColumn
            // 
            this.кодуслугиDataGridViewTextBoxColumn.DataPropertyName = "Код_услуги";
            this.кодуслугиDataGridViewTextBoxColumn.HeaderText = "Код_услуги";
            this.кодуслугиDataGridViewTextBoxColumn.Name = "кодуслугиDataGridViewTextBoxColumn";
            // 
            // наименованиеУслугиDataGridViewTextBoxColumn
            // 
            this.наименованиеУслугиDataGridViewTextBoxColumn.DataPropertyName = "Наименование услуги";
            this.наименованиеУслугиDataGridViewTextBoxColumn.HeaderText = "Наименование услуги";
            this.наименованиеУслугиDataGridViewTextBoxColumn.Name = "наименованиеУслугиDataGridViewTextBoxColumn";
            // 
            // ценарубDataGridViewTextBoxColumn
            // 
            this.ценарубDataGridViewTextBoxColumn.DataPropertyName = "Цена(руб)";
            this.ценарубDataGridViewTextBoxColumn.HeaderText = "Цена(руб)";
            this.ценарубDataGridViewTextBoxColumn.Name = "ценарубDataGridViewTextBoxColumn";
            // 
            // типуслугиDataGridViewTextBoxColumn
            // 
            this.типуслугиDataGridViewTextBoxColumn.DataPropertyName = "Тип_услуги";
            this.типуслугиDataGridViewTextBoxColumn.HeaderText = "Тип_услуги";
            this.типуслугиDataGridViewTextBoxColumn.Name = "типуслугиDataGridViewTextBoxColumn";
            // 
            // кодсотрудникаDataGridViewTextBoxColumn
            // 
            this.кодсотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Код_сотрудника";
            this.кодсотрудникаDataGridViewTextBoxColumn.HeaderText = "Код_сотрудника";
            this.кодсотрудникаDataGridViewTextBoxColumn.Name = "кодсотрудникаDataGridViewTextBoxColumn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(18, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 42);
            this.label2.TabIndex = 20;
            this.label2.Text = "Услуги";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(119, 478);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 22;
            this.button2.Text = "добавить мастера";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(25, 478);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(784, 513);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beautyShopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.услуги1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private BeautyShopDataSet beautyShopDataSet;
        private System.Windows.Forms.BindingSource услуги1BindingSource;
        private BeautyShopDataSetTableAdapters.Услуги1TableAdapter услуги1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодуслугиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеУслугиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценарубDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типуслугиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодсотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}