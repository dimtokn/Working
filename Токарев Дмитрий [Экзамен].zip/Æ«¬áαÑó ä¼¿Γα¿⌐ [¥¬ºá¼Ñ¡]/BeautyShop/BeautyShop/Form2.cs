﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeautyShop
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 form3= new Form3();
            form3.ShowDialog();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form4= new Form4();
            form4.ShowDialog();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 form5= new Form5();
            form5.ShowDialog();
            this.Close();
        }
    }
}
