﻿namespace BeautyShop
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.beautyShopDataSet = new BeautyShop.BeautyShopDataSet();
            this.сотрудники1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.сотрудники1TableAdapter = new BeautyShop.BeautyShopDataSetTableAdapters.Сотрудники1TableAdapter();
            this.расписание1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.расписание1TableAdapter = new BeautyShop.BeautyShopDataSetTableAdapters.Расписание1TableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.расписание1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.кодзаписиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОклиентаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.контактныйтелефонDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.времяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.мастерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типуслугиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодсотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодклиентаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.beautyShopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудники1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расписание1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расписание1BindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(18, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 42);
            this.label2.TabIndex = 22;
            this.label2.Text = "Записи";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(394, 73);
            this.label1.TabIndex = 21;
            this.label1.Text = "BeautyShop";
            // 
            // beautyShopDataSet
            // 
            this.beautyShopDataSet.DataSetName = "BeautyShopDataSet";
            this.beautyShopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // сотрудники1BindingSource
            // 
            this.сотрудники1BindingSource.DataMember = "Сотрудники1";
            this.сотрудники1BindingSource.DataSource = this.beautyShopDataSet;
            // 
            // сотрудники1TableAdapter
            // 
            this.сотрудники1TableAdapter.ClearBeforeFill = true;
            // 
            // расписание1BindingSource
            // 
            this.расписание1BindingSource.DataMember = "Расписание1";
            this.расписание1BindingSource.DataSource = this.beautyShopDataSet;
            // 
            // расписание1TableAdapter
            // 
            this.расписание1TableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодзаписиDataGridViewTextBoxColumn,
            this.фИОклиентаDataGridViewTextBoxColumn,
            this.контактныйтелефонDataGridViewTextBoxColumn,
            this.почтаDataGridViewTextBoxColumn,
            this.датаDataGridViewTextBoxColumn,
            this.времяDataGridViewTextBoxColumn,
            this.мастерDataGridViewTextBoxColumn,
            this.типуслугиDataGridViewTextBoxColumn,
            this.кодсотрудникаDataGridViewTextBoxColumn,
            this.кодклиентаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.расписание1BindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(0, 180);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1045, 225);
            this.dataGridView1.TabIndex = 23;
            // 
            // расписание1BindingSource1
            // 
            this.расписание1BindingSource1.DataMember = "Расписание1";
            this.расписание1BindingSource1.DataSource = this.beautyShopDataSet;
            // 
            // кодзаписиDataGridViewTextBoxColumn
            // 
            this.кодзаписиDataGridViewTextBoxColumn.DataPropertyName = "Код_записи";
            this.кодзаписиDataGridViewTextBoxColumn.HeaderText = "Код_записи";
            this.кодзаписиDataGridViewTextBoxColumn.Name = "кодзаписиDataGridViewTextBoxColumn";
            // 
            // фИОклиентаDataGridViewTextBoxColumn
            // 
            this.фИОклиентаDataGridViewTextBoxColumn.DataPropertyName = "ФИО_клиента";
            this.фИОклиентаDataGridViewTextBoxColumn.HeaderText = "ФИО_клиента";
            this.фИОклиентаDataGridViewTextBoxColumn.Name = "фИОклиентаDataGridViewTextBoxColumn";
            // 
            // контактныйтелефонDataGridViewTextBoxColumn
            // 
            this.контактныйтелефонDataGridViewTextBoxColumn.DataPropertyName = "Контактный_телефон";
            this.контактныйтелефонDataGridViewTextBoxColumn.HeaderText = "Контактный_телефон";
            this.контактныйтелефонDataGridViewTextBoxColumn.Name = "контактныйтелефонDataGridViewTextBoxColumn";
            // 
            // почтаDataGridViewTextBoxColumn
            // 
            this.почтаDataGridViewTextBoxColumn.DataPropertyName = "Почта";
            this.почтаDataGridViewTextBoxColumn.HeaderText = "Почта";
            this.почтаDataGridViewTextBoxColumn.Name = "почтаDataGridViewTextBoxColumn";
            // 
            // датаDataGridViewTextBoxColumn
            // 
            this.датаDataGridViewTextBoxColumn.DataPropertyName = "Дата";
            this.датаDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn.Name = "датаDataGridViewTextBoxColumn";
            // 
            // времяDataGridViewTextBoxColumn
            // 
            this.времяDataGridViewTextBoxColumn.DataPropertyName = "Время";
            this.времяDataGridViewTextBoxColumn.HeaderText = "Время";
            this.времяDataGridViewTextBoxColumn.Name = "времяDataGridViewTextBoxColumn";
            // 
            // мастерDataGridViewTextBoxColumn
            // 
            this.мастерDataGridViewTextBoxColumn.DataPropertyName = "Мастер";
            this.мастерDataGridViewTextBoxColumn.HeaderText = "Мастер";
            this.мастерDataGridViewTextBoxColumn.Name = "мастерDataGridViewTextBoxColumn";
            // 
            // типуслугиDataGridViewTextBoxColumn
            // 
            this.типуслугиDataGridViewTextBoxColumn.DataPropertyName = "Тип_услуги";
            this.типуслугиDataGridViewTextBoxColumn.HeaderText = "Тип_услуги";
            this.типуслугиDataGridViewTextBoxColumn.Name = "типуслугиDataGridViewTextBoxColumn";
            // 
            // кодсотрудникаDataGridViewTextBoxColumn
            // 
            this.кодсотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Код_сотрудника";
            this.кодсотрудникаDataGridViewTextBoxColumn.HeaderText = "Код_сотрудника";
            this.кодсотрудникаDataGridViewTextBoxColumn.Name = "кодсотрудникаDataGridViewTextBoxColumn";
            // 
            // кодклиентаDataGridViewTextBoxColumn
            // 
            this.кодклиентаDataGridViewTextBoxColumn.DataPropertyName = "Код_клиента";
            this.кодклиентаDataGridViewTextBoxColumn.HeaderText = "Код_клиента";
            this.кодклиентаDataGridViewTextBoxColumn.Name = "кодклиентаDataGridViewTextBoxColumn";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(106, 478);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "добавить мастера";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 478);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(1045, 513);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.beautyShopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудники1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расписание1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расписание1BindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private BeautyShopDataSet beautyShopDataSet;
        private System.Windows.Forms.BindingSource сотрудники1BindingSource;
        private BeautyShopDataSetTableAdapters.Сотрудники1TableAdapter сотрудники1TableAdapter;
        private System.Windows.Forms.BindingSource расписание1BindingSource;
        private BeautyShopDataSetTableAdapters.Расписание1TableAdapter расписание1TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодзаписиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОклиентаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn контактныйтелефонDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn времяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn мастерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn типуслугиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодсотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодклиентаDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource расписание1BindingSource1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}