﻿using BeautyShop.BeautyShopDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeautyShop
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "beautyShopDataSet.Сотрудники1". При необходимости она может быть перемещена или удалена.
            this.сотрудники1TableAdapter.Fill(this.beautyShopDataSet.Сотрудники1);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2=new Form2();
            form2.ShowDialog();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Сотрудники1TableAdapter.Update(BeautyShopDataSet.Сотрудники1);
            MessageBox.Show("Изменение внесено");
        }
    }
}
