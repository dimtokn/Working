﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BeautyShop
{
    public partial class FormGlav : Form
    {
        public FormGlav()
        {
            InitializeComponent();
        }

        private void FormGlav_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "beautyShopDataSet.Расписание1". При необходимости она может быть перемещена или удалена.
            this.расписание1TableAdapter.Fill(this.beautyShopDataSet.Расписание1);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
            this.Hide();
        }
    }
}
